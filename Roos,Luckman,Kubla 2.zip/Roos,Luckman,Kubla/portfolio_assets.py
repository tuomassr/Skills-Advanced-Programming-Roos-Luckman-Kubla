import pandas as pd

def show_top_assets(market_portfolio_weights, asset_names):
    """
    Asks the user if they want to see the top 10 assets in their optimal portfolio.
    If yes, prints a table of these assets with their weights.

    :param market_portfolio_weights: The weights of the assets in the market portfolio.
    :param asset_names: The names of the assets.
    """
    response = input("Do you want to see the top 10 assets in your optimal portfolio? (yes/y or no/n): ").strip().lower()

    if response in ['yes', 'y']:
        # Create a DataFrame for the weights
        weights_df = pd.DataFrame({'Asset': asset_names, 'Weight': market_portfolio_weights})

        # Sort the DataFrame by weight in descending order and take the top 10
        top_assets = weights_df.sort_values(by='Weight', ascending=False).head(10)

        # Display the top assets
        print("\nTop 10 Assets in your Optimal Portfolio:")
        print(top_assets)
        
    elif response in ['no', 'n']:
        print("Top 10 assets will not be displayed.")
    else:
        print("Invalid input. Please enter 'yes/y' or 'no/n'.")

