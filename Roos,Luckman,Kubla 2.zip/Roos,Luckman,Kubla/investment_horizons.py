# This section of the code gives the user his expected returns in monetary terms
# The user can define a time horizon and investment intervals in addition to the initial investment
# Then an alternative risk measure of VaR is given


import textwrap
import numpy as np
import matplotlib.pyplot as plt

w = 150

print(textwrap.fill(
    "We're ready to take the next step in building your investment strategy, factoring in your investment amount and time horizon. "
    "Your insights are valuable for a customized plan that resonates with your financial goals.", width=w))
print("\n")

def input_initial_investment(prompt):
    """
    Asks the user to input their initial investment amount. 
    The function ensures the response is a positive number representing currency.
    
    :param prompt: The question to ask the user.
    :return: The initial investment amount as a float.
    """
    # ensure input is a positive number
    while True:
        try:
            investment = float(input(prompt))
            if investment > 0:
                return investment
            else:
                print("\nPlease enter a positive amount for your investment.")
        except ValueError:
            print("\nInvalid input. Please enter a numeric value.")

######################
#######################

def input_investment_time_horizon(prompt):
    """
    Asks the user to input their investment time horizon in years. 
    The function ensures the response is a positive integer representing the number of years.
    
    :param prompt: The question to ask the user.
    :return: The investment time horizon as an integer.
    """
    # ensure input is a positive integer
    while True:
        try:
            time_horizon = int(input(prompt))
            if time_horizon > 0:
                return time_horizon
            else:
                print("\nPlease enter a positive number of years for your investment time horizon.")
        except ValueError:
            print("\nInvalid input. Please enter a whole number for the number of years.")



# Example of using the function
#initial_investment_amount = input_initial_investment("Please enter your initial investment amount: ")
#print(f"Your initial investment amount is: ${initial_investment_amount:.2f}")

initial_investment_amount = input_initial_investment(textwrap.fill("Please enter your initial investment amount: ", width=w))

# Call the function with a prompt wrapped to the desired width
investment_time_horizon = input_investment_time_horizon(textwrap.fill(
    "Please enter the number of years you plan to invest: ", width=w))


###################################
################################

def calculate_user_portfolio_outcomes(initial_investment, expected_return, risk):
    """
    Calculates and displays the user's expected cumulative return and annualized risk based on their inputted
    initial investment amount and investment time horizon.

    :param user_port_y: The expected annual return rate of the user's portfolio as a decimal.
    :param user_port_x: The annual standard deviation (risk) of the user's portfolio returns.
    """
    # Get user inputs
    #initial_investment = input_initial_investment("Enter your initial investment amount ($): ")
    #investment_time_horizon = input_investment_time_horizon("Enter your investment time horizon (years): ")

    time_horizon = investment_time_horizon    

    # Calculate cumulative return
    cumulative_return = initial_investment * ((1 + expected_return) ** time_horizon)
    
    # Calculate annualized risk
    annualized_risk = risk * (time_horizon ** 0.5)

    # Display the results
    print("\n")
    print(f"\nBased on an initial investment of ${initial_investment} over {investment_time_horizon} years:")
    print(f" - Your expected cumulative return is: ${cumulative_return:,.2f}")
    print(f" - Your annualized risk (Standard Deviation) is: {annualized_risk:.2%}")


# Calculate the outcomes for the user's portfolio
calculate_user_portfolio_outcomes(initial_investment_amount,0.1, 0.06)

print("\n")
print("\n--------")
print("\n")
print(textwrap.fill(
    "By investing as little as 10% more initally, you could get the following returns. ", width=w))
    
calculate_user_portfolio_outcomes(initial_investment_amount*1.1, 0.1, 0.06)


while True:
    dif_initial_amount = input("Would you like to increase your initial investment? (yes/no): ").strip().lower()
    
    if dif_initial_amount == "yes":
        initial_investment_amount = initial_investment_amount * 1.1
        break
    elif dif_initial_amount == "no":
        break  # Exit the loop if input is 'no'
    else:
        print("Please enter 'yes' or 'no'.")  # Handling invalid input

##################################################
##################################################
a = input("Press enter to continue:")
del a



def calculate_returns_and_risks(initial_investment, annual_return, standard_deviation):
    """
    Calculates and prints the expected cumulative returns and annualized risks for various alternative time horizons.

    :param initial_investment: The amount of money initially invested.
    :param annual_return: The expected annual return rate as a decimal (e.g., 0.07 for 7%).
    :param standard_deviation: The annual standard deviation (risk) of the returns.
    
    """
    time_horizons = [5, 10, 20, 30]
    for years in time_horizons:
        cumulative_return = initial_investment * ((1 + annual_return) ** years)
        annualized_risk = standard_deviation * (years ** 0.5)

        # Print the results
        print(f"For a {years}-year investment horizon:")
        print(f" - Expected Cumulative Return: ${cumulative_return:,.2f}")
        print(f" - Annualized Risk (Standard Deviation): {annualized_risk:.2%}")
        print("\n")
        print("-----")
        print("\n")

# Example usage:



print("\n###########################################################################################################\n")
print("\n")

print(textwrap.fill(
    "You can now see the investment outcomes for alternative time horizons"
    " based on your initial investment amount.", width=w))

a = input("Press enter to continue:")
del a
print("\n")

# Call the function with the defined parameters
calculate_returns_and_risks(initial_investment_amount, 0.1, 0.06)


#######################
######################
a = input("Press enter to continue:")
del a
print("\n")

def calculate_future_value(initial_investment, annual_return, additional_contribution, years, contribution_frequency):
    """
    Calculates the future value of an investment with regular contributions.

    :param initial_investment: The starting amount of money invested.
    :param annual_return: The annual return rate as a decimal.
    :param additional_contribution: The amount of additional regular contribution.
    :param years: The number of years the money is invested.
    :param contribution_frequency: 'monthly' or 'yearly' contributions.
    :return: The future value of the investment.
    """
    periods = years * 12 if contribution_frequency == 'm' else years
    if contribution_frequency == 'm':
        monthly_return = (1 + annual_return) ** (1/12) - 1
        future_value = initial_investment * ((1 + monthly_return) ** (periods)) + \
                       additional_contribution * (((1 + monthly_return) ** periods - 1) / monthly_return)
    else:  # yearly contributions
        future_value = initial_investment * ((1 + annual_return) ** years) + \
                       additional_contribution * (((1 + annual_return) ** years - 1) / annual_return)

    return future_value

#monthly_return = (1 + 0.1) ** (1/12) - 1
#future_value = 10000 * ((1 + monthly_return) ** (60)) + \
#               100 * (((1 + monthly_return) ** 60 - 1) / monthly_return)

def calculate_portfolio_outcomes_with_contributions(initial_investment, user_port_y, user_port_x):
    """
    Asks the user about making regular additional contributions and calculates the expected 
    cumulative returns and annualized risks for their investment over a specified time horizon.
    """
    # Get the investment time horizon from the user
    #investment_time_horizon = input_investment_time_horizon("Enter your investment time horizon (years): ")
    
    # Ask the user if they want to make additional contributions
    additional = input("Would you like to add to the investment regularly? (yes/no): ").strip().lower()
    if additional == 'yes':
        # Get the frequency and amount of additional contributions
        frequency = input("How often would you like to make additional investments? (monthly(m)/yearly(y)): ").strip().lower()
        while frequency not in ['m', 'y']:
            print("Invalid input. Please enter 'monthly' or 'yearly'.")
            frequency = input("How often would you like to make additional investments? (monthly(m)/yearly(y)): ").strip().lower()
        
        amount = float(input("How much would you like to regularly add ($): "))
        while amount <= 0:
            print("Please enter a positive amount.")
            amount = float(input("How much would you like to regularly add ($): "))
        
        # Calculate the cumulative return with additional contributions
        cumulative_return = calculate_future_value(initial_investment_amount, user_port_y, amount, investment_time_horizon, frequency)
    elif additional == 'no':
        # Calculate the cumulative return without additional contributions
        cumulative_return = initial_investment * ((1 + user_port_y) ** investment_time_horizon)
        frequency, amount = None, 0
    else:
        print("Invalid input. Please enter 'yes' or 'no'.")
        return calculate_portfolio_outcomes_with_contributions(initial_investment, user_port_y, user_port_x)
    
    # Calculate the annualized risk
    annualized_risk = user_port_x * (investment_time_horizon ** 0.5)
    
    # Display the results
    contribution_details = f" with additional contributions of ${amount} per {frequency} " if frequency else ""
    print(f"\nBased on an initial investment of ${initial_investment}{contribution_details}, over {investment_time_horizon} years:")
    print(f" - Expected Cumulative Return: ${cumulative_return:,.2f}")
    print(f" - Annualized Risk (Standard Deviation): {annualized_risk:.2%}")

print("\n")
print(textwrap.fill(
    "You will now have the opportunity to reevalute your investment strategy"
    " based on possible regular contributions.", width=w))

a = input("Press enter to continue:")
del a


# Example usage
# Assume initial_investment, user_port_y, and user_port_x are already defined
calculate_portfolio_outcomes_with_contributions(initial_investment_amount, 0.1, 0.06)

print("\n")
a = input("Press enter to continue:")

while True:
    different_amount = input("Would you like to try a different contribution amount? (yes/no): ").strip().lower()
    
    if different_amount == "yes":
        calculate_portfolio_outcomes_with_contributions(initial_investment_amount, 0.1, 0.06)
    elif different_amount == "no":
        break  # Exit the loop if input is 'no'
    else:
        print("Please enter 'yes' or 'no'.")  # Handling invalid input

a = input("Press enter to continue:")
del a
   


#################
################
print("\n")
print(textwrap.fill(
    "You can now see some measures of risk for your current investment strategy", width=w))
   
a = input("Press enter to continue:")
del a

print("\n")
print(textwrap.fill(
    "The first measure of risk you can consider is the Value-at-Risk (VAR)"
    "which helps assess the probability of the portfolio incurring losses"
    "over a determined threshold over a period of time.", width=w))



def input_confidence_level_and_threshold_loss():
    """
    Asks the user for their desired confidence level and threshold loss for VaR calculation.

    :return: A tuple containing the confidence level and threshold loss.
    """
    while True:
        try:
            confidence_input = float(input("Enter your desired confidence level (e.g., 0.95 for 95%): "))
            if 0 < confidence_input < 1:
                break
            else:
                print("Please enter a confidence level between 0 and 1 (exclusive).")
        except ValueError:
            print("Invalid input. Please enter a numeric value.")

    while True:
        try:
            threshold_loss_input = float(input("Enter your threshold loss value ($): "))
            if threshold_loss_input > 0:
                break
            else:
                print("Please enter a positive amount for the threshold loss.")
        except ValueError:
            print("Invalid input. Please enter a numeric value.")
    
    return confidence_input, threshold_loss_input

# Example usage of the function
confidence_level, threshold_loss = input_confidence_level_and_threshold_loss()
print(f"You have set the confidence level at {confidence_level:.2%} and the threshold loss at ${threshold_loss:,.2f}.")
print("\n")
      
        
from scipy.stats import norm

def calculate_var(annual_return, standard_deviation, confidence_level, investment_value, time_horizon):
    """
    Calculates the Value at Risk (VaR) for a given investment.

    :param annual_return: The expected annual return of the investment as a decimal.
    :param standard_deviation: The standard deviation of the investment's return.
    :param confidence_level: The confidence level as a decimal (e.g., 0.95 for 95%).
    :param investment_value: The current value of the investment.
    :param time_horizon: The time horizon in years over which to calculate VaR (default is 1 year).
    :return: The Value at Risk (VaR) for the specified confidence level and time horizon.
    """
    # Calculate the z-score for the given confidence level
    z_score = norm.ppf(1 - confidence_level)
    
    # Adjust standard deviation for the time horizon
    adjusted_std_dev = standard_deviation * (time_horizon ** 0.5)
    
    # Calculate VaR
    var = investment_value - (investment_value * (1 + annual_return) - z_score * adjusted_std_dev)
    return var

print("\n")

# Assuming user_port_y and user_port_x are already defined
var = calculate_var(0.1, 0.06, confidence_level, threshold_loss, investment_time_horizon)
print(f"The 1-year {confidence_level * 100}% VaR is: ${var:,.2f} - There is a {100 - (confidence_level * 100)}% chance that the investment will lose more than this amount over the next year.")












