import matplotlib.pyplot as plt

def plot_efficient_frontier(efficient_frontier, individual_risks, individual_returns, user_cov_matrix, 
                            market_portfolio_risk, market_portfolio_expected_return, 
                            mvp_risk, mvp_return, risk_free_rate, cml_x, cml_y):
    """
    Plots the efficient frontier, individual assets, market and minimum variance portfolios.

    :param efficient_frontier: DataFrame with 'Expected Return' and 'Risk' columns
    :param individual_risks: Numpy array of individual asset risks
    :param individual_returns: Numpy array of individual asset expected returns
    :param user_cov_matrix: DataFrame of covariance matrix with asset names as columns
    :param market_portfolio_risk: Risk of the market portfolio
    :param market_portfolio_expected_return: Expected return of the market portfolio
    :param mvp_risk: Risk of the minimum variance portfolio
    :param mvp_return: Return of the minimum variance portfolio
    :param risk_free_rate: Risk-free rate for Sharpe ratio calculation
    :param cml_x: X-axis values for Capital Market Line
    :param cml_y: Y-axis values for Capital Market Line
    """

    # Create a colormap for Sharpe ratio
    sharpe_colors = [plt.cm.viridis((ret - risk_free_rate) / risk) if risk != 0 else 0 for ret, risk in zip(efficient_frontier['Expected Return'], efficient_frontier['Risk'])]

    # Exclude assets with a risk greater than 0.25
    acceptable_risks = individual_risks <= 0.225
    filtered_individual_risks = individual_risks[acceptable_risks]
    filtered_individual_returns = individual_returns[acceptable_risks]
    filtered_asset_names = user_cov_matrix.columns[acceptable_risks]

    # Plotting
    plt.figure(figsize=(10, 6))

    # Efficient Frontier with color coding for Sharpe Ratio
    for i in range(len(efficient_frontier)):
        plt.scatter(efficient_frontier['Risk'][i], efficient_frontier['Expected Return'][i], color=sharpe_colors[i], label='Efficient Frontier' if i == 0 else "")

    # Market Portfolio
    plt.scatter(market_portfolio_risk, market_portfolio_expected_return, color='red', marker='+', s=200, label='Market Portfolio')

    # MVP
    plt.scatter(mvp_risk, mvp_return, color='blue', marker='+', s=200, label='Minimum Variance Portfolio')

    # Individual assets with acceptable risk
    for i, txt in enumerate(filtered_asset_names):
        plt.scatter(filtered_individual_risks[i], filtered_individual_returns[i], color='blue', marker='o', label=txt if i == 0 else "")
        plt.text(filtered_individual_risks[i], filtered_individual_returns[i], txt, fontsize=8)

    # Capital Market Line
    plt.plot(cml_x, cml_y, 'k--', label='Capital Market Line')
   
    # Labels and settings
    plt.title('Mean-Variance Efficient Frontier')
    plt.xlabel('Standard Deviation (Risk)')
    plt.ylabel('Expected Return')
    plt.xlim(0, max(efficient_frontier['Risk']) * 1.1)  # Setting the x-axis to start from 0 and slightly extend beyond the maximum risk
    plt.legend()
    plt.grid(True)

    plt.show()
    
    

def plot_final(efficient_frontier, individual_risks, individual_returns, user_cov_matrix, 
                            market_portfolio_risk, market_portfolio_expected_return, 
                            mvp_risk, mvp_return, risk_free_rate, cml_x, cml_y, user_port_x, user_port_y):
    """
    Plots the efficient frontier, individual assets, market and minimum variance portfolios.

    :param efficient_frontier: DataFrame with 'Expected Return' and 'Risk' columns
    :param individual_risks: Numpy array of individual asset risks
    :param individual_returns: Numpy array of individual asset expected returns
    :param user_cov_matrix: DataFrame of covariance matrix with asset names as columns
    :param market_portfolio_risk: Risk of the market portfolio
    :param market_portfolio_expected_return: Expected return of the market portfolio
    :param mvp_risk: Risk of the minimum variance portfolio
    :param mvp_return: Return of the minimum variance portfolio
    :param risk_free_rate: Risk-free rate for Sharpe ratio calculation
    :param cml_x: X-axis values for Capital Market Line
    :param cml_y: Y-axis values for Capital Market Line
    """

    # Create a colormap for Sharpe ratio
    sharpe_colors = [plt.cm.viridis((ret - risk_free_rate) / risk) if risk != 0 else 0 for ret, risk in zip(efficient_frontier['Expected Return'], efficient_frontier['Risk'])]

    # Exclude assets with a risk greater than 0.25
    acceptable_risks = individual_risks <= 0.225
    filtered_individual_risks = individual_risks[acceptable_risks]
    filtered_individual_returns = individual_returns[acceptable_risks]
    filtered_asset_names = user_cov_matrix.columns[acceptable_risks]

    # Plotting
    plt.figure(figsize=(10, 6))

    # Efficient Frontier with color coding for Sharpe Ratio
    for i in range(len(efficient_frontier)):
        plt.scatter(efficient_frontier['Risk'][i], efficient_frontier['Expected Return'][i], color=sharpe_colors[i], label='Efficient Frontier' if i == 0 else "")

    # Market Portfolio
    plt.scatter(market_portfolio_risk, market_portfolio_expected_return, color='red', marker='+', s=200, label='Market Portfolio')

    # MVP
    plt.scatter(mvp_risk, mvp_return, color='blue', marker='+', s=200, label='Minimum Variance Portfolio')

    # Individual assets with acceptable risk
    for i, txt in enumerate(filtered_asset_names):
        plt.scatter(filtered_individual_risks[i], filtered_individual_returns[i], color='blue', marker='o', label=txt if i == 0 else "")
        plt.text(filtered_individual_risks[i], filtered_individual_returns[i], txt, fontsize=8)

    # Capital Market Line
    plt.plot(cml_x, cml_y, '-', color='black', label='Capital Market Line')
   
    # Plot the point where the user's portfolio standard deviation intersects the CML
    plt.scatter(user_port_x, user_port_y, color='red', marker='*', s = 200, label='Your Portfolio')
    
    # Draw a dashed vertical line from the x-axis to the user's portfolio point
    plt.plot([user_port_x, user_port_x], [-0.05, user_port_y], color='grey', linestyle='--')

    # Draw a dashed horizontal line from the y-axis to the user's portfolio point
    plt.plot([0, user_port_x], [user_port_y, user_port_y], color='grey', linestyle='--')

    # Labels and settings
    plt.title('Mean-Variance Efficient Frontier')
    plt.xlabel('Standard Deviation (Risk)')
    plt.ylabel('Expected Return')
    plt.xlim(0, max(efficient_frontier['Risk']) * 1.1)  # Setting the x-axis to start from 0 and slightly extend beyond the maximum risk
    plt.legend()
    plt.grid(True)

    plt.show()
