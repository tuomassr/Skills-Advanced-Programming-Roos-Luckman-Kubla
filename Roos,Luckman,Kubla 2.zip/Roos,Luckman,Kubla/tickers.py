######
# This file contains the functions to retrieve tickers of US stocks (from S&P500)
# For each ticker symbol it also retrieves the INDUSTRY
#
# Additionally it contains the code for getting weekly returns for all these stocks for the past 5 years
#
# Required modules: pandas
# Install with: pip install pandas
# Install: openpyxl
######


import pandas as pd


# Function that gathers stocks from an Excel sheet, made so that other extra stocks could be easily added in a similar
# Excel sheet; function can take several excel sheets as input
def gather_stock_info(file_names, sheet_name, columns_to_read):
    """
    Function that gathers stocks from an Excel sheet, made so that other extra stocks could be easily added in a similar
    Excel sheet; function can take several Excel sheets as input

    :param file_names: List containing the names of the Excel files.
    :param sheet_name: Name of the sheet of interest within the Excel document.
    :param columns_to_read: Columns of interest.
    """
    # List to hold DataFrames
    dfs = []

    # Iterate over each file path
    for file_name in file_names:
        # Read the specified columns from the Excel file
        df = pd.read_excel(file_name, sheet_name=sheet_name, usecols=columns_to_read)
        # Append the DataFrame to the list
        dfs.append(df)

    # Concatenate all DataFrames in the list into one data frame
    combined_df = pd.concat(dfs, ignore_index=True)
    return combined_df


# TEST CODE FOR READING EXCEL SHEET USING THE FUNCTION
if __name__ == "__main__":
    file_names = ["iShares-Core-SP-500-UCITS-ETF-USD-Acc_fund.xlsx"]

    sheet_name = 'Holdings'
    columns_to_read = ['Issuer Ticker', 'Name', 'Sector', 'Location']

    # Call the function and get the combined DataFrame
    combined_stock_info = gather_stock_info(file_names, sheet_name, columns_to_read)

    # Create a mask to filter out rows where "Location" is "European Union" or Sector is Cash and/or Derivatives
    mask = (combined_stock_info["Location"] != "European Union") & (combined_stock_info["Sector"] !=
                                                                    "Cash and/or Derivatives")
    # Only keep the rows with boolean 1 in mask
    combined_stock_info = combined_stock_info[mask]
    del mask
    print(combined_stock_info.head()) # print head output to see how the code works

#The code below is used for webscraping and yahoo finance API. These are used to get up to date stock returns.
#For ease of use and optimisation we have used the below code and predownloaded historic financial data for the demonstration.
#The pre downloaded code is quicker and simpler to use, it is stored in .csv files called "stock_returns....csv"
"""
# import numpy as np
# import requests
# from bs4 import BeautifulSoup
# import datetime
# import yfinance as yf


# Tickers used by Blacrock in holdings of iShares ETFs do not perfectly correspond to the actual tickers,
# thus used webscrapping from wikipedia table to get them for S&P500 since there is a table available

if __name__ == "__main__"
    # Web scraping S&P500 Stocks (USA)
    # Webscraping to get the S&P 500 stocks and their ticker symbols which are needed to get current data on them
    response = requests.get("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies")
    soup = BeautifulSoup(response.content, 'html.parser')
    table = soup.find('table', {'id': 'constituents'})

    rows = table.find_all('tr')
    data_sp500 = []
    for row in rows[1:]:  # Skip the header row
        cols = row.find_all('td')
        data_sp500.append({
            'Symbol': cols[0].text.strip(),
            'Security': cols[1].text.strip(),
            'GICS Sector': cols[2].text.strip(),
            'GICS Sub-Industry': cols[3].text.strip()
        })

    # Convert to DataFrame
    df_sp500 = pd.DataFrame(data_sp500)
    # We Specify the country of the stocks. As we are getting them from the same index, they are from the same country
    df_sp500['Country'] = 'USA'




# We have the gathered data pre-loaded in a CSV file. This avoids the risk of API changes/problems or network errors
# For obtaining the CSV, used the following code in Jupyter Notebooks, as the API did not work within Python on macOS

# Function to gather weekly returns
def get_weekly_returns(ticker, start_date, end_date):

    Fetches weekly returns for a given stock ticker using yfinance.

    Parameters:
    ticker (str): Stock ticker symbol.
    start_date (str): Start date for the data in 'YYYY-MM-DD' format.
    end_date (str): End date for the data in 'YYYY-MM-DD' format.

    Returns:
    pandas.Series: Weekly returns for the given stock ticker.

    stock = yf.Ticker(ticker)
    data = stock.history(start=start_date, end=end_date, interval='1wk')
    
    # Calculate weekly returns
    weekly_returns = data['Close'].pct_change()

    return weekly_returns


start_date = '2018-11-01'
end_date = '2023-11-01'


#Gathering USA Stocks
stock_returns_us = pd.DataFrame()
for ticker in df_sp500["Symbol"]:
    try:
        # Get the daily returns for the ticker
        weekly_return = get_weekly_returns(ticker, start_date, end_date)
        
        # Add the daily returns to the stock_returns DataFrame
        stock_returns_us[ticker] = weekly_return
    except Exception as e:
        print(f"Error processing ticker {ticker}: {e}")
        continue
stock_returns_us = stock_returns_us.iloc[1:]
stock_returns_us = stock_returns_us.dropna(axis=1, how='all')
stock_returns_us.to_csv('stock_returns_us.csv', index=True)



#Gathering EU Stocks
stock_returns = pd.DataFrame()
for ticker in combined_stock_info["Issuer Ticker"]:
    try:
        # Get the daily returns for the ticker
        weekly_return = get_weekly_returns(ticker, start_date, end_date)
        
        # Add the daily returns to the stock_returns DataFrame
        stock_returns[ticker] = weekly_return
    except Exception as e:
        print(f"Error processing ticker {ticker}: {e}")
        continue
    
stock_returns_eu = stock_returns.iloc[1:]
stock_returns_eu = stock_returns_eu.dropna(axis=1, how='all')
stock_returns_eu.to_csv('stock_returns_eu.csv', index=True)
#Line to store the downloaded historic data as a .csv file for quicker use
"""


# Finally we have clean weekly stock returns for the stocks. Using these, we can find the expected return, variance and
# covariance.
# Hence we now have the returns for the stocks, and the possible restrictions set by the user
# We shall then construct the optimal portfolio
