######
# This file defines functions which prompt user to input their maximum tolerance of a loss
# 2 different functions:
#   for inputting loss in relative: input_max_loss_perc
#   or absolute terms: input_max_loss_dollar
#
# Finally, function calculate_average takes average of the obtained loss tolerances
######


# Question in relative terms
def input_max_loss_perc(prompt, loses_list):
    """
    Asks the user a question and adds their response to the responses list (loses_list).
    Function ensures the response is a number between 0 and 100; indicating willingness to lose from 0% up to 100%
    
    :param prompt: The question to ask the user.
    :param loses_list: The list to store responses.
    """
    # ensure input is a number within limits of 0 and 100 (max loss)
    while True:
        try:
            loss = float(input(prompt))
            if 0 <= loss <= 100:
                loses_list.append(loss)
                break
            else:
                print("\nPlease enter a loss using numbers between 0 and 100, meaning loss of 0% to 100%.")
        except ValueError:
            print("\nInvalid input. Please enter a numeric value.")


# Question in absolute terms - transforms to %
def input_max_loss_dollar(prompt, initial_investment, loses_list):
    """
    Asks the user for a maximum loss amount in dollar terms and converts it to a percentage based
    on the initial investment. The percentage is then added to the loses_list.
    
    :param prompt: The question to ask the user for maximum loss in dollar terms.
    :param initial_investment: The initial amount invested by the user.
    :param loses_list: The list to store percentage loss responses.
    """
    # ensure input is a number between 0 and the initial investment (max loss)
    while True:
        try:
            loss_dollar = float(input(prompt))
            if 0 <= loss_dollar <= initial_investment:
                loss_percent = (loss_dollar / initial_investment) * 100
                loses_list.append(loss_percent)
                break
            else:
                print(f"\nPlease enter a loss amount in dollars between 0 and {initial_investment}.")
        except ValueError:
            print("\nInvalid input. Please enter a numeric value.")



# Calculate the average maximum loss tolerance based on the list
def calculate_average(loses_list):
    """
    Calculates the average of the values in the responses list (loses_list).

    :param loses_list: The list of responses.
    :return: The average of the responses.
    """
    # Ensure that the list is not empty before making a division
    return sum(loses_list) / len(loses_list) if loses_list else 0



# TEST CODE THIS SCRIPT:
# only run when executing this script directly, not when it is imported
if __name__ == "__main__":
    # Initialize the list to store responses
    max_loses = []

    # Pose questions to the user
    print("\n Please consider the following hypothetical scenarios and answer them as"
          "\n realistically as possible, to properly assess your risk tolerance.\n")


    input_max_loss_perc("\nIf you invest in a portfolio, what is the maximum percentage loss" 
                   "\n from your initial investment that you would consider acceptable"
                   "\n over a one-year period? (input a number between 0 and 100; 100 meaning"
                   "\n you would be willing to lose 100%) ", max_loses)

    input_max_loss_perc("\n If there was a severe market downturn and the general market"
                   "\n declined by 20% over a year, what level of loss in your own"
                   "\n investment would you find acceptable in the same period, before"
                   "\n closing the position? (input number between 0 and 100) ", max_loses)

    input_max_loss_dollar("\n If you invested a sum of $50,000, at what point of absolute loss"
                   "\n in dollars (e.g., $5,000, $10,000, etc.) would you start feeling"
                   "\n extremely uncomfortable with the investment's performance? (input"
                   "\n an aboslute amount in $) ", 50000, max_loses)

    input_max_loss_dollar("\n Consider a long-term investment of $20,000 planned for a period"
                   "\n of 5-10 years. What is the highest amount of loss in dollars you"
                   "\n would tolerate in the short term (within the first year) without"
                   "\n changing your investment? (absolute amount in $) ", 20000, max_loses)

    input_max_loss_dollar("\n Consider an investment of $100,000 managed by a fund manager."
                   "\n Understanding that superior returns require taking on some risk,"
                   "\n what is the highest amount of loss in dollars you would tolerate"
                   "\n before pulling the money out of the fund? (absolute amount in $) ", 100000, max_loses)



    # Calculate and print the average loss tolerance
    average_loss = calculate_average(max_loses)
    print("\nAverage Maximum Loss Tolerance:", average_loss, "%")



























