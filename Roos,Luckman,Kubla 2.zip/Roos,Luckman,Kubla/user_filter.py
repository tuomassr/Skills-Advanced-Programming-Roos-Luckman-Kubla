######
# This file contains the functions that allow the users to apply filters on the stocks, based on their investment
# preferences. Therefore, they can exclude any specific industries.
#
######


# Filter by Industry
def format_string_sector(data):
    """
    Asks the user to enter a name or number of an industry to be removed
    Then it checks whether that identifier (name or number) is contained in the column "Sector" in the dataframe
    If it is a valid user input that it returns that sector's name

    :param data: the dataframe containing the variable Sector
    """
    while True:
        input_string = input("Enter the sector name or its number to remove: ")

        if input_string.isdigit():  # If user input is an index
            index = int(input_string) - 1  # Adjust for zero-based indexing
            if 0 <= index < len(data["Sector"].unique()):
                # If a valid index return the Sector name of this index in uniform form
                return data["Sector"].unique()[index].lower().replace(" ", "")
            else:
                print("Invalid index. Please try again.")
        elif input_string.strip():  # If user input is a string = name
            sector_name = input_string.lower().replace(" ", "")
            # Check if the sector_name is in the dataframe
            if sector_name in data["Sector"].str.lower().str.replace(" ", "").unique():
                return sector_name
            else:
                print(f"'{sector_name}' is not a valid sector. Please try again.")
        else:
            print("Invalid input. Please enter a valid sector name or number.")


# def filter_sector(input_data):
#     """
#     This function allows the user to decide whether to exclude any specific sector
#     then it filters the user input sector out of the dataframe

#     :param input_data: the dataframe from which to remove the sector
#     """
#     data = input_data
#     print("These are the available sectors:")
#     unique_values = data["Sector"].unique()

#     # Print each unique value with its number, start enumerating with 1
#     for number, industry in enumerate(unique_values, start=1):
#         print(f"{number}: {industry}")

#     while True:
#         usr_input = input("\nWould you like to exclude a sector? (y/yes ELSE no): ")

#         if usr_input.lower() in ["y", "yes"]:
#             # Get all unique Sectors
#             unique_values = data["Sector"].unique()

#             # Print each unique value with its number, start enumerating with 1
#             for number, industry in enumerate(unique_values, start=1):
#                 print(f"{number}: {industry}")

#             # Use the format_string_sector() function to get valid input (sector to be removed)
#             sector = format_string_sector(data)

#             # Format the Sector column for comparison with output from format_string_sector (lowercase, no spaces)
#             formatted_sector_column = data["Sector"].str.lower().str.replace(" ", "")

#             # Create a boolean mask where True indicates the rows to keep
#             bool_mask = formatted_sector_column != sector

#             # Use the mask to filter the DataFrame
#             filter_sector_data = data[bool_mask]
#             data = filter_sector_data

#         else:
#             break  # Exit the loop if the user doesn't want to exclude a country

#     print(f"\nYou have a total of {len(data)} equities that fit your choices. We will now construct the optimal portfolio out of them.")
#     print(f"Your sector exclusion(s) removed {503 - len(data)} possible equities to use in your optimal portfolio")

#     return data


def filter_sector(input_data):
    """
    This function allows the user to decide whether to exclude up to three specific sectors
    then it filters the user input sector out of the dataframe

    :param input_data: the dataframe from which to remove the sector
    """
    data = input_data
    excluded_count = 0  # Counter for the number of sectors excluded

    print("These are the available sectors:")
    unique_values = data["Sector"].unique()

    # Print each unique value with its number, start enumerating with 1
    for number, industry in enumerate(unique_values, start=1):
        print(f"{number}: {industry}")

    while excluded_count < 3:
        usr_input = input("\nWould you like to exclude a sector? (y/yes ELSE no): ")

        if usr_input.lower() in ["y", "yes"]:
            # Get all unique Sectors
            unique_values = data["Sector"].unique()

            # Print each unique value with its number, start enumerating with 1
            for number, industry in enumerate(unique_values, start=1):
                print(f"{number}: {industry}")

            # Use the format_string_sector() function to get valid input (sector to be removed)
            sector = format_string_sector(data)

            # Format the Sector column for comparison with output from format_string_sector (lowercase, no spaces)
            formatted_sector_column = data["Sector"].str.lower().str.replace(" ", "")

            # Create a boolean mask where True indicates the rows to keep
            bool_mask = formatted_sector_column != sector

            # Use the mask to filter the DataFrame
            filter_sector_data = data[bool_mask]
            data = filter_sector_data
            excluded_count += 1  # Increment the counter

        else:
            print("Please do not remove more than 3 sectors. You are only limited to removing 3.")
            break  # Exit the loop if the user doesn't want to exclude a country

    print(f"\nYou have a total of {len(data)} equities that fit your choices. We will now construct the optimal portfolio out of them."
          "Now based on the covariances and expected returns of the stocks you have selected, we will construct the optimal portfolio.")
    print(f"Your sector exclusion(s) removed {len(input_data) - len(data)} possible equities to use in your optimal portfolio")

    return data



# TEST CODE
if __name__ == "__main__":
    # for testing get the data from Excel, importing using a function from tickers.py
    import tickers
    file_names = ["iShares-Core-SP-500-UCITS-ETF-USD-Acc_fund.xlsx"]

    sheet_name = 'Holdings'
    columns_to_read = ['Issuer Ticker', 'Name', 'Sector', 'Location']

    # Call the function and get the combined DataFrame
    combined_stock_info = tickers.gather_stock_info(file_names, sheet_name, columns_to_read)

    # Create a mask to filter out rows where "Location" is "European Union" or Sector is Cash and/or Derivatives
    mask = (combined_stock_info["Location"] != "European Union") & (combined_stock_info["Sector"] !=
                                                                    "Cash and/or Derivatives")
    # Only keep the rows with boolean 1 in mask
    combined_stock_info = combined_stock_info[mask]
    del mask
    print(combined_stock_info.head())  # print head output to see how the code works

    filtered_data = filter_sector(combined_stock_info)


