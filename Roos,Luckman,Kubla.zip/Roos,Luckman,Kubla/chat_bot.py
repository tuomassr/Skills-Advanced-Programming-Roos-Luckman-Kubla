from openai import OpenAI
client = OpenAI(api_key = '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')

assistant = client.beta.assistants.create(
    name = "Financial Advisor",
    instructions = "You are a financial advisor giving short answers.",
    tools = [{"type": "code_interpreter"}],
    model="gpt-4-1106-preview",
)

thread = client.beta.threads.create()
print(thread)

financial_info = (
    "Your average Maximum Loss Tolerance is 7.4%. "
    "Your optimal portfolio consists of a market Beta of 0.42. "
)

usr_question = input("Do you have any questions? ")

prompt = f"Based on the following information: {financial_info}, answer the following question: {usr_question}"

message = client.beta.threads.messages.create(
    thread_id = thread.id,
    role = "user",
    content = prompt
)

run = client.beta.threads.runs.create(
    thread_id = thread.id,
    assistant_id = assistant.id
)

messages = client.beta.threads.messages.list(
    thread_id = thread.id
)


for message in reversed(messages.data):
    print(message.role + ": " + message.content[0].text.value)



    
    
    
    
    
    
    
    
    
    
    
    




