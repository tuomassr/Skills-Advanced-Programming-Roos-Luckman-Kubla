#### READ ME ####
"""
For a detailed description of the project, please view the seperate "description.pdf" included that describes the whole project
In a short summary:
    1. We derive the user's risk aversion
    2. We retrieve historic stock returns from the individual s&p500 stocks (503 of them)
    3. From these the user can remove stocks in certain industries that he doesnt want to be exposed to
    4. Based on the allowed stocks and their derived expected returns and risk, the efficient frontier is constructed
    5. On the efficient frontier the market portfolio is constructed
    6. Based on the user's risk aversion, the optimal user portfolio is constructed from the risk free asset and market portfolio
    7. From this the user's personal expected return and risk is deducted
    8. Next the user can define the desired investment amount, investment intervals, and time horizon
    9. Finally, the expected monetary returns for the user are displayed with the user desired VaR

Please do look at the plots that we make. 
For them we construct an unique efficient frontier for the equities that the user chooses.
Additionally on the second plot we place the users uniqe portfolio on the Capital Market Line (CML).
This position on the CML is determined based on the user derived risk tolerance and aversion.

The actaul calculations for the returns end up being higher than one would typically expect.
This is due to the nature of the optimisation process and the following assumption:
    Our theory expects past returns to be depictive of future ones.
    As we derive the expected return from past performance without a penalty factor,
    the returns end up being slightly unrealistic in their expectation.
    However, this is typical for the process that we are implementing, and not fault of the code.
"""
#### END ####


# Our individual made scripts (modules) are used in the following order:
# 1. max_loss
# 2. utility_function
# 3. user_filter
# 4. tickers
# 5. efficient_frontier_plot
# 6. portfolio_assets
# 7. investment_horizons   <-   Called only at the end

import max_loss
import utility_function
import user_filter
import tickers
import efficient_frontier_plot
import portfolio_assets

# Install libraries:
# Pip install is needed for these incase you do not have them pre-loaded
# These are required for the code to run properly
import textwrap
import cvxpy
import numpy as np
import pandas as pd
#import requests  # <- Only required for the webscraping section of the code, which is not in use as we pre-loaded the data for demonstration purposes
#from bs4 import BeautifulSoup  # <- Only required for the webscraping section of the code, which is not in use as we pre-loaded the data for demonstration purposes
import cvxpy as cp
from tqdm import tqdm
import threading
import warnings
import os 

# Automatically set the working directory for ease of use
cur_script_path = os.path.abspath(__file__)
cur_dir = os.path.dirname(cur_script_path)
os.chdir(cur_dir)

w = 150

print("\n")
print(textwrap.fill(
    "WELCOME TO YOUR PERSONAL ROBO-ADVISOR. With the use of a few questions, we are creating the optimal portfolio for "
    "you based on your specific risk tolerance and your specific wishes with regard to your investments. "
    "We will inform you about your expected returns.", width=w))
print("\n")
print(textwrap.fill("DISCLAIMER!"
                    "The Content is for informational purposes only, you should not construe any such information or "
                    "other material as investment, financial, or any other advice. It does not constitute a "
                    "solicitation, recommendation or endorsement, to buy or sell any securities or other financial "
                    "instruments.", width=w))
a = input("Press enter to continue:")
del a

# GET INVESTORS MAXIMUM RISK TOLERANCE
# Create several scenario-based questions to get investor"s risk tolerance;

# Initialize empty list to store responses
max_loses = []

# Pose questions to the user
print("\n")
print(textwrap.fill("LET US BEGIN CONSTRUCTING YOUR OPTIMAL PORTOFLIO. "
                    "Please consider the following 5 hypothetical scenarios and respond to them as realistically as "
                    "possible, for us to properly assess your risk tolerance.", width=w))

print("\n###########################################################################################################\n")
max_loss.input_max_loss_perc(textwrap.fill("1.) If you invest in a portfolio, what is the maximum percentage loss "
                                           "from your initial investment that you would consider acceptable "
                                           "over a one-year period? (input a number between 0 and 100; 100 meaning "
                                           "you would be willing to lose 100%): ", width=w), max_loses)

print("\n")
max_loss.input_max_loss_perc(textwrap.fill("2.) If there was a severe market downturn and the general market "
                                           "declined by 20% over a year, what level of loss in your own "
                                           "investment would you find acceptable in the same period, before "
                                           "closing the position? (input number between 0 and 100): ", width=w),
                             max_loses)

print("\n")
max_loss.input_max_loss_dollar(textwrap.fill("3.) If you invested a sum of $50,000, at what point of absolute loss "
                                             "in dollars (e.g., $5,000, $10,000, etc.) would you start feeling "
                                             "extremely uncomfortable with the investment's performance? (input "
                                             "an aboslute amount in $): ", width=w), 50000, max_loses)

print("\n")
max_loss.input_max_loss_dollar(textwrap.fill("4.) Consider a long-term investment of $20,000 planned for a period "
                                             "of 5-10 years. What is the highest amount of loss in dollars you "
                                             "would tolerate in the short term (within the first year) without "
                                             "changing your investment? (absolute amount in $): ", width=w), 20000,
                               max_loses)

print("\n")
max_loss.input_max_loss_dollar(textwrap.fill("5.) Consider an investment of $100,000 managed by a fund manager. "
                                             "Understanding that superior returns require taking on some risk, "
                                             "what is the highest amount of loss in dollars you would tolerate "
                                             "before pulling the money out of the fund? (absolute amount in $): ",
                                             width=w), 100000, max_loses)

# Calculate and print the average loss tolerance
average_loss = max_loss.calculate_average(max_loses)
print("\n###########################################################################################################\n")
print("Thank you for your cooperation. \nYour average Maximum Loss Tolerance is", round(average_loss, 3), "%")

a = input("Press enter to continue:")
del a

# GET RISK AVERSION
risk_free_rate = 0.04  # Example: 4% risk-free rate
expected_market_return = 0.10  # Example: 10% expected market return
market_std_dev = 0.20  # Example: 20% market standard deviation
# use the above average of the max tolerable loss
max_acceptable_loss = average_loss / 100 * (-1)

individual_beta = utility_function.calculate_beta(risk_free_rate, expected_market_return, market_std_dev,
                                                  max_acceptable_loss)

#Limit the individual beta to max 1.225
if individual_beta > 1.225:
    individual_beta = 1.225
    

print("\nYour optimal portfolio consists has a market Beta of ", round(individual_beta, 2),
      ". Namely, that is the weight in the market portfolio, whereas ", 100*round(1 - individual_beta, 2),
      "% is the percentage weight in the risk-free assets.")

# Add explanatory note in case that weight on the market portfolio is greater than 1
if individual_beta > 1:
    print("Negative weight means you are shorting this asset, and being leveraged on the other asset.")


expected_market_return = 0.10  # Example: 8% expected market return
risk_free_rate = 0.04  # Example: 2% risk-free rate
# individual_beta = 0.55  # Example beta calculated from Step 1
market_variance = market_std_dev ** 2

risk_aversion_coefficient = utility_function.calculate_risk_aversion_coefficient(expected_market_return, risk_free_rate,
                                                                                 individual_beta, market_variance)
print("\nYour risk Aversion Coefficient (A) is: ", round(risk_aversion_coefficient, 2))
print("\nNamely, your individual utility function is U = E(R) - 0.5 * ", round(risk_aversion_coefficient, 2),
      " * variance")


# NOW GET THE EQUITIES AVAILABLE TO INVEST IN
file_names = ["iShares-Core-SP-500-UCITS-ETF-USD-Acc_fund.xlsx"]
sheet_name = "Holdings"
columns_to_read = ["Issuer Ticker", "Name", "Sector", "Location"]

##################################################################
file_paths = ["iShares-Core-SP-500-UCITS-ETF-USD-Acc_fund.xlsx"]
##################################################################

# Call the function and get the combined DataFrame (function defined in script tickers)
# Here we have only basic information about all the possible stocks
#This information about the available stocks is used to filter out unwanted sectors by the user
combined_stock_info = tickers.gather_stock_info(file_names, sheet_name, columns_to_read)

#Here the df is "cleaned" from unwanted/wrong entries
# Create a mask to filter out rows where "Location" is "European Union" or Sector is Cash and/or Derivatives
mask = (combined_stock_info["Location"] != "European Union") & (combined_stock_info["Sector"] !=
                                                                "Cash and/or Derivatives")
# Only keep the rows with boolean 1 in mask
combined_stock_info = combined_stock_info[mask]

a = input("Press enter to continue:")
del a

print("\n###########################################################################################################\n")

print(textwrap.fill("Now lets construct your portfolio based on your risk preferences. We are considering all the "
                    "stocks in the S&P500. First lets see if there are any specific sectors that you would not like "
                    "not invest in. We suggest that you exclude a sector that you are heavily involved in.", width=w))
print("\n")

# filter_sector function defined in the script user_filter
filtered_stocks = user_filter.filter_sector(combined_stock_info)

print("\n###########################################################################################################\n")

a = input("Press enter to continue:")
del a


#Now that the user has determined the range of possible stocks to invest in, their respective historical data is gathered
#The historic data from the possible stocks is used to determine an optimal portfolio out of the availible assets
#The optimal portfolio will change in accordance to the excluded sectors
#The more sectors are excluded, the worse the investment opportunities become

#Read the pre downloaded historic data from all possible stocks.
#As discussed, originally this data is webscraped and api downloaded on the tickers.py module
#For robustness and speed it is predownloaded for demonstration purposes
# stock_returns_eu = pd.read_csv("/Users/tuomas/Desktop/Semester 1/Skills Programming/Skills Programming/stock_returns_eu_5year.csv", index_col=0, parse_dates=True)
# stock_returns_us = pd.read_csv("/Users/tuomas/Desktop/Semester 1/Skills Programming/Skills Programming/stock_returns_us_5year.csv", index_col=0, parse_dates=True)

stock_returns_us = pd.read_csv("stock_returns_usa.csv", index_col=0, parse_dates=True)
stock_returns_eu = pd.read_csv("stock_returns_eur.csv", index_col=0, parse_dates=True)


#Combining the two into one dataframe
combined_stock_returns = pd.concat([stock_returns_eu, stock_returns_us], axis=1)

#Removing/filter bad data
combined_stock_returns = combined_stock_returns.dropna(axis=1, how="any")
combined_stock_returns = combined_stock_returns.loc[:, (combined_stock_returns != 0).any(axis=0)]

#Get the mean annualized returns for each stock -> Used for removing extreme outliers
#These extremes are removed because they are unlikely to give an accurate indication of future returns
returns_mean_expected = combined_stock_returns.mean()
returns_mean_expected_ann = (1 + returns_mean_expected) ** 52 - 1

#Filter out the extreme stocks / outliers
extreme_tickers = returns_mean_expected_ann[(returns_mean_expected_ann < -0.1) | (returns_mean_expected_ann > 0.25)].index
                             
#Removing extreme stocks               
combined_stock_returns = combined_stock_returns.drop(columns=extreme_tickers)

#Now we select only the stocks and their historic returns based on the user filtered stocks
#Only use historic stock returns that are allowed by the user (neglecting the unwanted sectors)

# Extracting the list of tickers from filtered_data
tickers = filtered_stocks["Issuer Ticker"].unique()

# Selecting the corresponding columns from combined_stock_returns
selected_columns = [ticker for ticker in tickers if ticker in combined_stock_returns.columns]

# Creating a new DataFrame with the selected columns
user_stock_returns = combined_stock_returns[selected_columns]

#We need to remove missing values from the returns matrix before we can take covariances
user_stock_returns = user_stock_returns.dropna(axis=1, how="any")
user_stock_returns = user_stock_returns.loc[:, (user_stock_returns != 0).any(axis=0)]

#Get the mean annualized returns for each user selected stock -> This is used as the expected return of each stock
user_returns_mean_expected = user_stock_returns.mean()
user_mean_expected_ann = (1 + user_returns_mean_expected) ** 52 - 1
user_mean_expected_ann = np.array(user_mean_expected_ann)

#Take the covariance matrix of the user selected stocks, from which the optimal portfolio is constructed
user_cov_matrix = user_stock_returns.cov()

# Number of assets
n = len(user_cov_matrix)

#We are limiting the user to only long positions (no negative weights/short selling)
#Because of this restriction, finding the optimal weights is slightly more complex due to the lack of an analytical solution
#Therefore to find the optimal weights with variable restrictions, we are using a numerical method to the weights

# Define the optimization variables
weights = cp.Variable(n)

# Define the objective function (minimize portfolio variance)
# In case the user removes a lot of sectors, we use the cvxpy.psd_wrap
# The matrix becomes positive semi-definite as required by the optimization method
objective = cp.Minimize(cp.quad_form(weights, cvxpy.psd_wrap(user_cov_matrix)))

#Range for the weights that can be invested into a single asset in the portfolio
min_weight = 0
max_weight = 0.1

# Define the constraints
constraints = [cp.sum(weights) == 1, 
               weights >= min_weight, 
               weights <= max_weight]

#Here we are using a convex optimization method to find the minima -> Minimum variance portfolio
problem = cp.Problem(objective, constraints)
problem.solve()
problem.status

# Extract the optimal weights -> Minimum Variance Portfolio
optimal_weights_mvp = weights.value

# Convert to DataFrame for better visualization
weights_df = pd.DataFrame(optimal_weights_mvp, index=user_cov_matrix.columns, columns=["Weight"])

# Calculate the expected return and standard deviation with optimal weights
expected_return_annual = np.dot(optimal_weights_mvp, user_mean_expected_ann)

#Multiplied by sqrt(52) to get annual
expected_std_dev_annual = np.sqrt(np.dot(optimal_weights_mvp.T, np.dot(user_cov_matrix, optimal_weights_mvp))) * np.sqrt(52)

#The process for finding the market portfolio is slightly more involved
#The idea is to guess weight values towards the sharpe ratio maximizing value
#Due to the numerical method used to solve it, it is highly unlickly that the theoretical optimum is reached, but it will be very close

# The expected values may be too large and impossible -> breaks the optiization
# To solve this we use try: except: to solve the problem of impossible optimizaitons
def optimize_portfolio(weights, user_cov_matrix, constraints, return_data):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # Ignore cvxpy warnings
        try:
            problem = cp.Problem(cp.Minimize(cp.quad_form(weights, cvxpy.psd_wrap(user_cov_matrix))), constraints)
            problem.solve()
            if problem.status not in ["infeasible", "unbounded"]:
                optimal_weights = weights.value
                min_risk = np.sqrt(np.dot(optimal_weights.T, np.dot(user_cov_matrix, optimal_weights))) * np.sqrt(52)
                return_data.extend([True, min_risk, optimal_weights])
        except Exception:
            # Catch any exceptions but do not print or raise them
            return_data.extend([False])

# Define the range for target_returns
target_returns = np.linspace(0.1, 0.35, 100)

efficient_frontier_data = []

# tqdm is used here to create a progress bar
with tqdm(total=len(target_returns), desc="Calculating Efficient Frontier") as pbar:
    for target_return in target_returns:
        retry_count = 0
        success = False

        while retry_count < 1 and not success:
            # Define the optimization variables
            weights = cp.Variable(n)

            # Add the desired expected return as a constraint to the optimisation
            constraints = [cp.sum(weights) == 1, 
                           weights >= min_weight, 
                           weights <= max_weight,
                           cp.matmul(user_mean_expected_ann, weights) == target_return]

            # Data to return from thread
            return_data = []

            # Start optimization in a separate thread
            optimization_thread = threading.Thread(target=optimize_portfolio, args=(weights, user_cov_matrix, constraints, return_data))
            optimization_thread.start()

            # Wait for 1 second or until thread completes
            optimization_thread.join(timeout=1)

            # Check if thread is still alive
            if optimization_thread.is_alive():
                # If so, it took too long
                optimization_thread.join()  # Ensure the thread is cleaned up
                break

            # Check if optimization was successful
            if return_data and return_data[0]:
                # If successful, append data
                efficient_frontier_data.append((target_return, return_data[1], return_data[2]))
                success = True
            else:
                retry_count += 1

        pbar.update(1)
        if not success:
            break  # Breaks out of the for loop if the optimization failed even after retries
print("We have now constructed the efficient frontier")

a = input("Press enter to continue:")
del a

# Convert results to DataFrame
efficient_frontier = pd.DataFrame(efficient_frontier_data, columns=["Expected Return", "Risk", "Weights"])

# Calculate Sharpe ratios
sharpe_ratios = (efficient_frontier["Expected Return"] - risk_free_rate) / efficient_frontier["Risk"]

# Find the portfolio with the highest Sharpe ratio
max_sharpe_idx = sharpe_ratios.idxmax()
market_portfolio_weights = efficient_frontier.loc[max_sharpe_idx, "Weights"]

# Convert market portfolio weights to DataFrame
market_portfolio_df = pd.DataFrame([market_portfolio_weights], columns=user_cov_matrix.columns)

# Extract the expected return of the market portfolio
market_portfolio_expected_return = efficient_frontier.loc[max_sharpe_idx, "Expected Return"]

# Extract the risk (standard deviation) of the market portfolio
market_portfolio_risk = efficient_frontier.loc[max_sharpe_idx, "Risk"]

# Calculate the variance of the market portfolio
# Variance is the square of the standard deviation (risk)
market_portfolio_variance = market_portfolio_risk ** 2

# Calculate the risk and return of individual assets for plotting
individual_risks = np.sqrt(np.diag(user_cov_matrix)) * np.sqrt(52)
individual_returns = user_mean_expected_ann

# Find the Minimum Variance Portfolio (MVP) from efficient_frontier_data
mvp_index = np.argmin([risk for _, risk, _ in efficient_frontier_data])
mvp_risk = efficient_frontier["Risk"][mvp_index]
mvp_return = efficient_frontier["Expected Return"][mvp_index]

# Capital Market Line (CML)
cml_x = np.linspace(0, max(efficient_frontier["Risk"]), 100)
cml_y = risk_free_rate + (market_portfolio_expected_return - risk_free_rate) / market_portfolio_risk * cml_x


# We have now all the necessary data to construct the user specific mean-variance plot with the efficient frontier
# Using the function, we are plotting the efficient frontier, portfolios, CML and the individual assets on the MV-Frontier
efficient_frontier_plot.plot_efficient_frontier(efficient_frontier, individual_risks, individual_returns, user_cov_matrix, 
                            market_portfolio_risk, market_portfolio_expected_return, 
                            mvp_risk, mvp_return, risk_free_rate, cml_x, cml_y)

print("\n###########################################################################################################\n")
print(f"The expected return of the minimum variance portfolio is: {round(expected_return_annual, 3)}  with a variance of {round(expected_std_dev_annual, 3)}")
print(f"Expected Return of the Market Portfolio: {round(market_portfolio_expected_return,3 )}")
print(f"Variance of the Market Portfolio: {round(market_portfolio_variance, 3)}")
print(f"You achieved a maximum Sharpe Ratio of: {round(sharpe_ratios[max_sharpe_idx], 3)}")
print("Please look at the plot. It shows the efficient frontier, CML, the optimal portfolio (market portfolio) and the individual stocks")
a = input("Press enter to continue:")
del a

print("\n###########################################################################################################\n")
print("Now based on your risk aversion coefficient we will show your specific portfolio on the optimal CML Line."
      "Your portfolio is a mixture of the risk free asset and the optimal portfolio."
      "This combination provides you with the highest possible expected return for your given risk tolerance.")

#Slowdown for the user
a = input("Press enter to continue:")
del a

# Here the position of the users optimal portfolio is calculated with the user derived beta
# We find the risk of the user portfolio
#To get y-value, we find the vertical intersect with the CML
user_port_x = market_portfolio_risk * individual_beta
user_port_y = risk_free_rate + (market_portfolio_expected_return - risk_free_rate) / market_portfolio_risk * user_port_x



efficient_frontier_plot.plot_final(efficient_frontier, individual_risks, individual_returns, user_cov_matrix, 
                            market_portfolio_risk, market_portfolio_expected_return, 
                            mvp_risk, mvp_return, risk_free_rate, cml_x, cml_y,user_port_x, user_port_y)

print("\n###########################################################################################################\n")
#Function for asking user whether he wants to see top assets in his portfolio
portfolio_assets.show_top_assets(market_portfolio_df.values[0], user_cov_matrix.columns)

a = input("Press enter to continue:")
del a

print("\n###########################################################################################################\n")
print(f"Based on your individual Risk Aversion coefficient of: {round(risk_aversion_coefficient, 2)}"
      "\n"
      f"And based on your individual Beta of: {round(individual_beta, 2)}"
      "\n"
      f"We achieved your optimal portfolio with the following:"
      "\n"
      f"Expected Return (annual): {round(user_port_y * 100, 3) }%"
      "\n"
      f"Standard Deviation (Risk) (annual): {round(user_port_x, 2) * 100}%")

print("\n###########################################################################################################\n")

a = input("Press enter to continue:")
del a

#Expected Return for the user
expected_return = user_port_y
#Standard deviation for the user
standard_deviation = user_port_x
#Variance for the user
variance = standard_deviation**2


####
#Now the following part of the code is fully written in the investment_horizons file
#As we simply import the investment_horizons.py the final section of the code will run
#For more detail on the code, simply view the file investment_horizons

#The reason for this method is the relative independence of the two sections
#The investment_horizons section requires only three variables from the earlier code, namely:
#       expected_return & standard_deviation & variance
#Therefore the tasks for the project could be quite effectively split between the two sections, and easily integrated this way
####

import investment_horizons
print("\n###########################################################################################################\n")

#Now this is the end of the code
print("Thank you for using RiskWise Portfolio Designer")
print("\n")
print("If there are any questions around the program, please do not hesitate to contact us:")
print("\n")
print("tuomas.roos@student.unisg.ch")
print("jan.luckman@student.unisg.ch")
print("matus.kubla@student.unisg.ch")




















