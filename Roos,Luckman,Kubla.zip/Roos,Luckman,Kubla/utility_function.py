######
# This file defines a TWO-STEP approach to obtaining individuals RISK AVERSION A
# Assumption of utility function: U = E(R) - 0.5 * A * variance
#
# Required modules: scipy
# Install with: pip install scipy
######

# Install libraries:
import scipy.stats as stats

"""
We use a basic utility function for the Robo-Advisor
This utility function is used to model the trade-off between risk and return for an investor.
It is formulated as: U = E(R) - 0.5 * A * variance
With:
U is the utility score,
E(R) is the expected return of the investment,
A is the risk aversion coefficient (higher value means more risk-averse),
variance is the measure of the investment's risk (volatility).
(This form is a simplification commonly used in mean-variance analysis and portfolio theory.)

Assuming efficient market portfolio = portfolio of an investor consists of risk-free asset and market portfolio

To derive individual's risk aversion, a TWO-STEP APPROACH IS USED:
 
STEP 1: Determine individual's β given their personal risk tolerance
  Ask user about maximum acceptable loss (x) within a 95% CI
  Standardize that return by (x - E[Rp])/standard deviation
  Assuming normal distribution of return, calculate the z-score for this max loss
  Rearrange to get individual's βm given their risk tolerance
  βm = (x - Rf) / (E(Rm) - Rf - z * σm)

STEP 2: Calculate the risk aversion coefficient A
  Start with utility function U = E(R) - 0.5 * A * variance
  For E[R] use CAPM = rf + βm * (E[R] - rf)
  Maximise utility by taking derivative w.r.t. βm and set it to 0
  Rearrange to: βm = (E[Rm] - Rf) / (A * variance)
  Insert βm and get A;
A = (E[Rm] - Rf) / (βm * variance)
"""

# STEP 1:
def calculate_beta(risk_free_rate, expected_market_return, market_std_dev, max_acceptable_loss):
    """
    Calculate the individual's beta based on their maximum acceptable loss.
    
    :param risk_free_rate: Risk-free rate (Rf)
    :param expected_market_return: Expected market return (E(Rm))
    :param market_std_dev: Standard deviation of the market (σm)
    :param max_acceptable_loss: Maximum acceptable loss specified by the investor
    :return: Beta (β) of the individual
    """

    # Calculate the z-score for 95% confidence interval
    z_score = stats.norm.ppf(0.05)  # 5% tail for 95% confidence

    # Calculate beta (β)
    beta = (max_acceptable_loss - risk_free_rate) / (expected_market_return - risk_free_rate + z_score * market_std_dev)

    return beta



# STEP 2:
def calculate_risk_aversion_coefficient(expected_market_return, risk_free_rate, individual_beta, market_variance):
    """
    Calculate the risk aversion coefficient (A) for an individual.

    :param expected_market_return: Expected market return (E(Rm))
    :param risk_free_rate: Risk-free rate (Rf)
    :param individual_beta: Beta (β) of the individual
    :param market_variance: Variance of the market (σ²m)
    :return: Risk aversion coefficient (A)
    """
    A = (expected_market_return - risk_free_rate) / (individual_beta * market_variance)
    return A


# TEST CODE for calculate_beta:
if __name__ == "__main__":
    risk_free_rate = 0.04  # Example: 4% risk-free rate
    expected_market_return = 0.10  # Example: 10% expected market return
    market_std_dev = 0.20  # Example: 20% market standard deviation
    max_acceptable_loss = -0.10  # Example: -10% maximum acceptable loss

    individual_beta = calculate_beta(risk_free_rate, expected_market_return, market_std_dev, max_acceptable_loss)
    print("Individual's Beta:", individual_beta)


# TEST CODE for calculate_risk_aversion_coefficient:
if __name__ == "__main__":
    expected_market_return = 0.10  # Example: 8% expected market return
    risk_free_rate = 0.04  # Example: 2% risk-free rate
    individual_beta = 0.55  # Example beta calculated from Step 1
    market_variance = 0.04  # Example: Market variance (σ²m)

    risk_aversion_coefficient = calculate_risk_aversion_coefficient(expected_market_return, risk_free_rate, individual_beta, market_variance)
    print("Risk Aversion Coefficient (A):", risk_aversion_coefficient)

















